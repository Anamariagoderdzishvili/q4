import requests
from bs4 import BeautifulSoup
import csv
import time

url = 'https://www.goodreads.com/'
pages = 5
duration = 20
file = open('goodreads.csv', 'w', encoding='UTF-8_sig', newline='\n')
csv_obj = csv.writer(file)
csv_obj.writerow(['სათაური', 'ავტორი', 'რეიტინგი'])
books = {'groups': 'top_250', 'start': 1}
h = {'Accept-Language': 'en-US'}

while books['start'] < 250:
    response = requests.get(url, params=books, headers=h)
    content = response.text
    soup = BeautifulSoup(content, 'html.parser')
    titles = soup.find_all("a", class_="bookTitle")
    authors = soup.find_all("a", class_="authorName")
    ratings = soup.find_all("span", class_="rating")

    for title, author, rating in zip(titles, authors, ratings):
        csv_obj.writerow([title.text.strip(), author.text.strip(), rating.text.strip()])
        print(title.text.strip(), author.text.strip(), rating.text.strip())

    books['start'] += 50
    time.sleep(duration)

file.close()
